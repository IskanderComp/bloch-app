export interface Mailbox{
    id: string;
    name: string;
    parentId: string | null;
    
}
