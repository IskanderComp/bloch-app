export class Mail {
    id: number;
    subject: string;
    creator: string;
    created_At: string;
}
