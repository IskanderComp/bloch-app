export interface LoginForm {
    username: string;
    password: string;
    grant_type?: string;
    scope?: string;
}
