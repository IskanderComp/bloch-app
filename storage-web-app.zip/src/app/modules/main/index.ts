export  { MainModule } from './main.module';
