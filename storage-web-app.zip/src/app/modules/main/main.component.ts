import { Component, Output, Input } from '@angular/core';
// import { UserService } from '../../providers/user.service';
// import { User } from '../../models/user';
import './main.component.scss';

@Component({
    selector: 'bc-main',
    templateUrl: './main.component.html'
})
export class MainComponent {

    // currentUser: User;
    //
    // isClicked: boolean = false;
    // constructor(private userService: UserService) {
    //     this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    // }
    //
    // showUserNav() {
    //     if (!this.isClicked) {
    //         this.isClicked = true
    //     } else if (this.isClicked = true){
    //         this.isClicked = false
    //     }
    // }

}
