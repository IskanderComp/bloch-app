import { Component } from '@angular/core';
import './auth.component.scss';

@Component({
    selector: 'bc-auth',
    templateUrl: './auth.component.html'
})

export class AuthComponent {}
