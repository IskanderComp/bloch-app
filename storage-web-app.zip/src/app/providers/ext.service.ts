import { Injectable } from '@angular/core';
import * as ext from './ext.config.json';

// let extConfig;

export const extObject = ext.extensions;

// @Injectable()
// export class ConfigService {
//     public configValues: any;
//     constructor() {
//         this.configValues = Object.assign({}, envConfig);
//     }
// }
